/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultancy;


import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author AGU
 */
public class case_detail extends javax.swing.JFrame {
    String id="";
    connect c;
    public case_detail(String id,String cameFrom) throws SQLException{
        
        
        initComponents();
        
        this.id=id;
        info1.setText("job");
        info1.setVisible(true);
        info2.setText("suitor name");
        info2.setVisible(true);
        info3.setText(" ");
        info3.setVisible(false);
        jTextField6.setVisible(false);
        jLabel3.setVisible(false);
        jLabel7.setVisible(false);
        jDateChooser1.setVisible(false);
        jDateChooser3.setVisible(false);
        c=new connect();
        
        if(cameFrom.equals("client")){
            jButton1.setVisible(false);
        }
        if(cameFrom.equals("cases")){
            jButton3.setVisible(false);
        }
        System.out.println("asfd");
        ArrayList<String> liste=c.getEmployee();
        for(String s:liste){
            System.out.println(s);
            jComboBox2.addItem(s);
            
        }
        
        
    }
     public case_detail(String id) throws SQLException{
          initComponents();
        this.id=id;
        info1.setText("job");
        info1.setVisible(true);
        info2.setText("suitor name");
        info2.setVisible(true);
        info3.setText(" ");
        info3.setVisible(false);
        jTextField6.setVisible(false);
        jLabel3.setVisible(false);
        jLabel7.setVisible(false);
        jDateChooser1.setVisible(false);
        jDateChooser3.setVisible(false);
        c=new connect();
         System.out.println("fads");
         ArrayList<String> liste=c.getEmployee();
        for(String s:liste){
            jComboBox2.addItem(s);
        }
        
    }
     
 
    /**
     * Creates new form case_detail
     */
    public case_detail(int id) throws SQLException, ParseException {
        
        initComponents();
        System.out.println("afsd");
         ArrayList<String> liste=c.getEmployee();
        for(String s:liste){
            jComboBox2.addItem(s);
        }
        this.id=String.valueOf(id);
        jButton3.setVisible(false);
        c=new connect();
        
      ArrayList<String> list =  c.case_show_detail(id);
        System.out.println("2");
        System.out.println(list.size()+"size");
            String s[] = list.get(0).split(",");
            String k[] = list.get(1).split(",");
            
            
            System.out.println("3");
           String items[] ={ "Malpractice", "Intellectual Property", "Immigration", "Business", "Family"};
           for(int i=0; i<items.length; i++){
               if(items[i].equalsIgnoreCase(s[0])){
                          jComboBox1.setSelectedIndex(i);

               }
        }
           System.out.println("1");
          switch(s[0]){
              case "Immigration": 
                  jTextField4.setText(k[0]);
                  jTextField5.setText(k[1]);
                  jTextField6.setText(k[2]);
                  
                  info1.setVisible(true);
                  info2.setVisible(true);
                  info3.setVisible(true);
                  jTextField4.setVisible(true);
                  jTextField5.setVisible(true);
                  jTextField6.setVisible(true);
                  
                  break;
              case "Business":
                   jTextField4.setText(k[0]);
                  jTextField5.setText(k[1]);
                  jTextField6.setText(k[2]);
                  
                  info1.setVisible(true);
                  info2.setVisible(true);
                  info3.setVisible(true);
                  
                  jTextField4.setVisible(true);
                  jTextField5.setVisible(true);
                  jTextField6.setVisible(true);
                  
                  break;
              case "Malpractice":
                  
                   jTextField4.setText(k[0]);
                  jTextField5.setText(k[1]);
                 
                  
                  info1.setVisible(true);
                  info2.setVisible(true);
                  info3.setVisible(false);
                  jTextField4.setVisible(true);
                  jTextField5.setVisible(true);
                  jTextField6.setVisible(false);
                  
                  break;
                  
              case "Intellectual Property":
                  jTextField4.setText(k[0]);
                  
                    info1.setVisible(true);
                  info2.setVisible(false);
                  info3.setVisible(false);
                  jTextField4.setVisible(true);
                  jTextField5.setVisible(false);
                  jTextField6.setVisible(false);
                  
                  break;
                  
              case "Family":
                  
                  jTextField4.setText(k[0]);
                  jTextField5.setText(k[1]);
                 
                  
                  info1.setVisible(true);
                  info2.setVisible(true);
                  info3.setVisible(false);
                  jTextField4.setVisible(true);
                  jTextField5.setVisible(true);
                  jTextField6.setVisible(false);
                  
                  break;
                  
                  
          }
          
          
          
         
          
     String t=    jComboBox2.getSelectedItem().toString();
           
       
           String d = s[2];
   java.util.Date da = new SimpleDateFormat("yyyy-MM-dd").parse(d);
   jDateChooser1.setDate(da);
   jDateChooser1.setToolTipText(s[2]);
           
           
           
           String status [] = { "Not started", "Checklist", "Documents provided ", "Working on the case", "Sent for signature"};
           
           for(int i=0; i<status.length; i++){
               if(status[i].equalsIgnoreCase(s[3])){
                   jComboBox3.setSelectedIndex(i);
               }
           }
           
           jTextField7.setText(s[4]);
           
           String date_new1 = s[5];
   java.util.Date date_new = new SimpleDateFormat("yyyy-MM-dd").parse(date_new1);
   jDateChooser3.setDate(date_new);
   jDateChooser3.setToolTipText(s[5]);
           
           
         
           
           
   String date = s[6];
   java.util.Date date2 = new SimpleDateFormat("yyyy-MM-dd").parse(date);
   jDateChooser2.setDate(date2);
   jDateChooser2.setToolTipText(s[6]);
            
            
            
            jTextArea4.setText(s[7]);
            jTextArea1.setText(s[8]);
            jTextArea2.setText(s[9]);
            jTextArea3.setText(s[10]);
            
            
            
           
           
           
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        info1 = new javax.swing.JLabel();
        info2 = new javax.swing.JLabel();
        info3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jDateChooser3 = new com.toedter.calendar.JDateChooser();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jComboBox2 = new javax.swing.JComboBox<>();

        jTextField1.setText("jTextField1");

        jLabel9.setText("jLabel9");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel1.setText("Case Type : ");

        jLabel2.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel2.setText("Assigned to :");

        jLabel3.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel3.setText("Last Action Date :");

        jLabel5.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel5.setText("Case Status : ");

        jLabel6.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel6.setText("Matter Code :");

        jComboBox1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Malpractice", "Intellectual Property", "Immigration", "Business", "Family", " " }));
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1İtemStateChanged(evt);
            }
        });

        jComboBox3.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Not started", "Checklist", "Documents provided ", "Working on the case", "Sent for signature", " " }));

        jLabel7.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel7.setText("Starting Date :");

        jLabel8.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel8.setText("Deadline :");

        info1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        info1.setText("                           job :");
        info1.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                info1ComponentShown(evt);
            }
        });

        info2.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        info2.setText("            suitor name : ");

        info3.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel10.setText("Practice :");

        jLabel11.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel11.setText("Scope of Work :");

        jLabel12.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel12.setText("Payment Terms :");

        jLabel13.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel13.setText("Remarks :");

        jButton1.setFont(new java.awt.Font("Candara Light", 0, 14)); // NOI18N
        jButton1.setText("update");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Candara Light", 0, 14)); // NOI18N
        jButton2.setText("clients");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTextField4.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N

        jTextField6.setInheritsPopupMenu(true);
        jTextField6.setOpaque(false);

        jTextField7.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N

        jDateChooser2.setDateFormatString("d MMM y ");
        jDateChooser2.setPreferredSize(new java.awt.Dimension(20, 20));

        jButton3.setFont(new java.awt.Font("Candara Light", 0, 14)); // NOI18N
        jButton3.setText("Add");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Candara Light", 0, 14)); // NOI18N
        jButton4.setText("cases");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTextArea4.setColumns(20);
        jTextArea4.setRows(5);
        jScrollPane1.setViewportView(jTextArea4);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jScrollPane4.setViewportView(jTextArea3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jComboBox3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField7)
                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                    .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(80, 80, 80)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel7)
                                .addComponent(jLabel8))
                            .addComponent(info1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(info2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
                            .addComponent(info3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField6)
                            .addComponent(jTextField5)
                            .addComponent(jDateChooser3, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField4)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(jScrollPane1)))))
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel11)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel13)
                            .addGap(35, 35, 35)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(38, 38, 38)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(33, 33, 33))
            .addGroup(layout.createSequentialGroup()
                .addGap(241, 241, 241)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 731, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel10)
                            .addComponent(jDateChooser3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel8)
                            .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel11)
                                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(info1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(info2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(info3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel12)
                                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(jButton2)
                        .addComponent(jButton3)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void info1ComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_info1ComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_info1ComponentShown

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            // TODO add your handling code here:
            Clients a = new Clients();
            a.setVisible(true);
            setVisible(false);
        } catch (SQLException ex) {
            Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        ArrayList<String> list=new ArrayList<>();
        list.add("id");//0
        list.add(id);//1
        String case_type = jComboBox1.getSelectedItem().toString();
        list.add("case_type");//2
        list.add(case_type);//3
        String assign = jComboBox2.getSelectedItem().toString();
        list.add("assigned_to");//4
        list.add(assign);//5
      
        
        
        String case_status = jComboBox3.getSelectedItem().toString();
        list.add("case_status");//6
        list.add(case_status);//7
        String matter = jTextField7.getText().toString();
        list.add("matter");//8
        list.add(matter);//9
        
         String deadline = String.valueOf(jDateChooser2.getDate().getTime()); 
         list.add("deadline");//10
         list.add(deadline);//11
         
         
         
         String payment = jTextArea4.getText().toString();
         list.add("payment");//12
         list.add(payment);//13
         
         String practice = jTextArea1.getText().toString();
         list.add("practice");//14
         list.add(practice);//15
        String scope = jTextArea2.getText().toString();
        list.add("scope");//16
        list.add(scope);//17
        String remark = jTextArea3.getText().toString();
        list.add("remarks");//18
        list.add(remark);//19
        
        try {
            c.addCase(list);
            
        } catch (SQLException ex) {
            Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(case_type.equalsIgnoreCase("Immigration")){
           
             
          String curr_visa = jTextField4.getText().toString();
          
          String exp = jTextField5.getText().toString();
          String next = jTextField6.getText().toString();
          
            try {
                c.case_im_add(curr_visa, exp, next);
                jTextField4.setText("");
                jTextField5.setText("");
                jTextField6.setText("");
                
            } catch (SQLException ex) {
                Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
         else if(case_type.equalsIgnoreCase("business")){
          
             
           String transaction = jTextField4.getText().toString();
          String defendant = jTextField5.getText().toString();
          String lawyer_name = jTextField6.getText().toString();
             
            try {
                c.case_bus_add(transaction, defendant, lawyer_name);
                jTextField4.setText("");
                jTextField5.setText("");
                jTextField6.setText("");
                
            } catch (SQLException ex) {
                Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
         else if(case_type.equalsIgnoreCase("malpractice")){
           
             
          String job = jTextField4.getText().toString();
          String suitor_name = jTextField5.getText().toString();
        
            try {
                c.case_mal_add(job, suitor_name);
                jTextField4.setText("");
                jTextField5.setText("");
                
                
            } catch (SQLException ex) {
                Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
         else if(case_type.equalsIgnoreCase("family")){
          String spouse_name = jTextField4.getText().toString();
          String conselsual = jTextField5.getText().toString();
          
            try {
                c.case_fam_add(spouse_name, conselsual);
                jTextField4.setText("");
                jTextField5.setText("");
               
                
            } catch (SQLException ex) {
                Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
            }
             
         }
         else if(case_type.equalsIgnoreCase("Intellectual Property")){
             String transaction = jTextField4.getText().toString();
             
            try {
                c.case_ip_add(transaction);
                jTextField4.setText("");
               
                
            } catch (SQLException ex) {
                Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
        
        JOptionPane.showMessageDialog(this, "case added");
        
        jTextField7.setText("");
        jTextArea1.setText("");
        jTextArea2.setText("");
        jTextArea3.setText("");
        jTextArea4.setText("");
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox1İtemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1İtemStateChanged
        // TODO add your handling code here:
        String case_type = jComboBox1.getSelectedItem().toString();
        
     if(case_type.equalsIgnoreCase("Immigration")){
             info1.setText("current visa");
             info2.setText("expiration date");
             info3.setText("next visa");
             
             info1.setVisible(true);
             info2.setVisible(true);
             info3.setVisible(true);
             
              jTextField4.setVisible(true);
              jTextField5.setVisible(true);
               jTextField6.setVisible(true);
             
      
         }
         else if(case_type.equalsIgnoreCase("business")){
             info1.setText("transaction");
             info2.setText("defendant");
             info3.setText("lawyer name");
             
             info1.setVisible(true);
             info2.setVisible(true);
             info3.setVisible(true);
             
             jTextField4.setVisible(true);
               jTextField5.setVisible(true);
                jTextField6.setVisible(true);
             
         }
         else if(case_type.equalsIgnoreCase("malpractice")){
             info1.setText("job");
             info2.setText("suitor name");
            
             info1.setVisible(true);
             info2.setVisible(true);
             info3.setVisible(false);
             
         jTextField4.setVisible(true);
               jTextField5.setVisible(true);
          jTextField6.setVisible(false);
             
         }
         else if(case_type.equalsIgnoreCase("family")){
             info1.setText("spouse name");
             info2.setText("conselsual");
             info3.setText(" ");
             
             info1.setVisible(true);
             info2.setVisible(true);
             info3.setVisible(false);
             
             
             jTextField4.setVisible(true);
              jTextField5.setVisible(true);
         
          jTextField6.setVisible(false);
             
         }
         else if(case_type.equalsIgnoreCase("Intellectual Property")){
             info1.setText("transaction");
             
             info1.setVisible(true);
             info2.setVisible(false);
             info3.setVisible(false);
             
             jTextField4.setVisible(true);
              jTextField5.setVisible(false);
              jTextField6.setVisible(false);
         }
        
    }//GEN-LAST:event_jComboBox1İtemStateChanged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            // TODO add your handling code here:
            // burda update yapcak yada save yapcak yeni bilgileri
            
            ArrayList<String> list=new ArrayList<>();
            list.add("case_id");//0
            list.add(id);//1
            String case_type = jComboBox1.getSelectedItem().toString();
            list.add("case_type");//2
            list.add(case_type);//3
            String assign = jTextField2.getText().toString();
            list.add("assigned_to");//4
            list.add(assign);//5
            
            
            
            String case_status = jComboBox3.getSelectedItem().toString();
            list.add("case_status");//6
            list.add(case_status);//7
            
            String matter = jTextField7.getText().toString();
            list.add("matter_code");//8
            list.add(matter);//9
            
            
            
            
            String deadline = String.valueOf(jDateChooser2.getDate().getTime());
            list.add("deadline");//10
            list.add(deadline);//11
            
            
            
            String payment = jTextArea4.getText().toString();
            list.add("payment");//12
            list.add(payment);//13
            
            String practice = jTextArea1.getText().toString();
            list.add("practice");//14
            list.add(practice);//15
            String scope = jTextArea2.getText().toString();
            list.add("scope");//16
            list.add(scope);//17
            String remark = jTextArea3.getText().toString();
            list.add("remarks");//18
            list.add(remark);//19
            
            c.update_case(list);
            
            JOptionPane.showMessageDialog(null, "updated!", "", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            // TODO add your handling code here:
            Cases c = new Cases();
            c.setVisible(true);
            setVisible(false);
        } catch (SQLException ex) {
            Logger.getLogger(case_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel info1;
    private javax.swing.JLabel info2;
    private javax.swing.JLabel info3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private com.toedter.calendar.JDateChooser jDateChooser3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    // End of variables declaration//GEN-END:variables
}
