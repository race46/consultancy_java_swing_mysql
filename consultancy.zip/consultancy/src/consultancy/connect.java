/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consultancy;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SpringLayout;

/**
 *
 * @author AGU
 */



public class connect {
    
   
    
  private String kullanıcı_adı = "root";
    private String db_name= "database";
    private String host = "localhost";
    private int port= 3306;
    
    private Connection con = null;
    
    private Statement statement = null;
    
    private PreparedStatement preparedstatement = null;
    
    String url= "jdbc:mysql://" + host +":"+ port +"/" + db_name;
    
     public connect(){
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            
           
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(connect.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            con=(Connection) DriverManager.getConnection(url,"root",null);
            System.out.println("baglandi");
          
        } catch (SQLException ex) {
            System.out.println("baglanmadi");
            Logger.getLogger(connect.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
      
    }
     
     public ArrayList<String> employees_table() throws SQLException {
                ArrayList<String> list=new ArrayList();
		Statement s=(Statement) con.createStatement();
		
		ResultSet r=s.executeQuery("select *from employee");
		while (r.next()) list.add(r.getInt("emp_id")+","+r.getString("fname")+","+r.getString("lname")+","+r.getString("office"));
                return list;
	}
	
     
     public ArrayList<String> client_table() throws SQLException { // ıd fnam lname
                ArrayList<String> list=new ArrayList();
		Statement s=(Statement) con.createStatement();
		
		ResultSet r=s.executeQuery("select * from client inner join case_first on client.client_id=c_id");
		while (r.next()) list.add(r.getInt("client_id")+","+r.getString("fname")+","+r.getString("lname")+","+r.getString("assigned_to")+","+(System.currentTimeMillis()-Long.parseLong(r.getString("millis"))/1000/60/60/24));
                return list;
	}
     
      public ArrayList<String> client_show() throws SQLException { // ıd fnam lname
                ArrayList<String> list=new ArrayList();
		Statement s=(Statement) con.createStatement();
		
		ResultSet r=s.executeQuery("select * from client");
		while (r.next()) list.add(r.getInt("client_id")+","+r.getString("fname")+","+r.getString("lname"));
                return list;
	}
      public void addCase(ArrayList<String> list) throws SQLException{
          String sorgu = "INSERT INTO case_first(assigned_to,case_type, case_status,matter_code,deadline,payment,practice,scope,remarks,c_id) VALUES" + "(?,?,?,?,?,?,?,?,?,?)"; 
          PreparedStatement preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setString(1, list.get(5));
          preparedStatement.setString(2, list.get(3));
          preparedStatement.setString(3, list.get(7));
          preparedStatement.setString(4, list.get(9));
          preparedStatement.setTimestamp(5, new Timestamp(Long.parseLong(list.get(11))));
          preparedStatement.setString(6, list.get(13));
          preparedStatement.setString(7, list.get(15));
          preparedStatement.setString(8, list.get(17));
          preparedStatement.setString(9, list.get(19));
          preparedStatement.setInt(10, Integer.parseInt(list.get(1)));
          
          preparedStatement .executeUpdate();
          
              
              
              
      }
      
      public void case_im_add(String curr_visa,String exp_date,String next_visa) throws SQLException{
         Statement s=(Statement) con.createStatement();
         ResultSet r=s.executeQuery("select case_id from case_first");
         int id=0;
		while (r.next()) {
                    id=r.getInt("case_id");
                }
          String sorgu = "INSERT INTO case_im(case_id, curr_visa, exp_date, next_visa) VALUES" + "(?,?,?,?)";
          PreparedStatement preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setInt(1,id );
          preparedStatement.setString(2,curr_visa );
          preparedStatement.setString(3,exp_date );
          preparedStatement.setString(4,next_visa );
          preparedStatement .executeUpdate();
          
          
          
      }
      public void case_bus_add(String t, String d, String l) throws SQLException{
          
          Statement s=(Statement) con.createStatement();
         ResultSet r=s.executeQuery("select case_id from case_first");
         int id=0;
		while (r.next()) {
                    id=r.getInt("case_id");
                }
          String sorgu = "INSERT INTO case_bus(case_id, tsaction, defendant, lawyer_name) VALUES" + "(?,?,?,?)";
          PreparedStatement preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setInt(1,id );
          preparedStatement.setString(2,t );
          preparedStatement.setString(3,d );
          preparedStatement.setString(4,l );
          preparedStatement .executeUpdate();
      }
      public void case_mal_add(String j, String sui) throws SQLException{
          
           Statement s=(Statement) con.createStatement();
         ResultSet r=s.executeQuery("select case_id from case_first");
         int id=0;
		while (r.next()) {
                    id=r.getInt("case_id");
                }
          String sorgu = "INSERT INTO case_mal(case_id, job, suitor_name) VALUES" + "(?,?,?)";
          PreparedStatement preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setInt(1,id );
          preparedStatement.setString(2,j);
          preparedStatement.setString(3,sui);
          preparedStatement .executeUpdate();
          
      }
      public void case_fam_add(String spo, String c) throws SQLException{
          
           
           Statement s=(Statement) con.createStatement();
         ResultSet r=s.executeQuery("select case_id from case_first");
         int id=0;
		while (r.next()) {
                    id=r.getInt("case_id");
                }
          String sorgu = "INSERT INTO case_fam(case_id, spouse_name, consensual) VALUES" + "(?,?,?)";
          PreparedStatement preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setInt(1,id );
          preparedStatement.setString(2,spo);
          preparedStatement.setString(3,c);
          preparedStatement .executeUpdate();
      }
      public void case_ip_add(String transaction) throws SQLException{
          
             Statement s=(Statement) con.createStatement();
         ResultSet r=s.executeQuery("select case_id from case_first");
         int id=0;
		while (r.next()) {
                    id=r.getInt("case_id");
                }
          String sorgu = "INSERT INTO case_ip(case_id, tsaction) VALUES" + "(?,?)";
          PreparedStatement preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setInt(1,id );
          preparedStatement.setString(2,transaction);
                  
          preparedStatement .executeUpdate();
      }
      
      public void client_add(String fname, String  lname, String sex, String ini_contact,String  ini_remark, String  phone,  String email, String company,String  position,String  status,String address) throws SQLException{
          
          String sorgu = "INSERT INTO client(fname,lname, email ,sex ,phone,client_status, address , company ,position ,initial_contact, initial_remark) VALUES" + "(?,?,?,?,?,?,?,?,?,?,?)"; 
          PreparedStatement preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setString(1, fname);
          preparedStatement.setString(2, lname);
          preparedStatement.setString(3, email);
          preparedStatement.setString(4, sex );
          preparedStatement.setString(5, phone);
          preparedStatement.setString(6, status);
          preparedStatement.setString(7, address);
          preparedStatement.setString(8, company);
          preparedStatement.setString(9, position);
          preparedStatement.setString(10, ini_contact);
           preparedStatement.setString(11, ini_remark);
          
          
          preparedStatement .executeUpdate();
      }
   
      
      public ArrayList<String> client_show_detail(String id) throws SQLException{
          ArrayList<String> list=new ArrayList();
		Statement s=(Statement) con.createStatement();
		
		ResultSet r=s.executeQuery("select * from client where client_id = "+id);
		while (r.next()) list.add(r.getInt("client_id")+","+r.getString("fname")+","+r.getString("lname")+","
                        +r.getString("email")+","+r.getString("sex")+","+r.getString("phone")+","+r.getString("client_status")
                        +","+r.getString("address")+","+r.getString("company")+","+r.getString("position")+","+r.getString("initial_contact")
                        +","+r.getString("initial_remark"));
                return list;
          
      }
      
      public ArrayList<String> caseData() throws SQLException{
          ArrayList<String> liste=new ArrayList();
          Statement s=(Statement) con.createStatement();
          ResultSet r=s.executeQuery("select * from case_first inner join client on case_first.c_id=client.client_id");
          
          while(r.next()){
              liste.add(r.getInt("case_id")+","+r.getString("case_type")+","+r.getString("fname")+","+r.getString("lname")+","+r.getString("case_status")+","+r.getString("client_status")+","+r.getTimestamp("last_action_date").getTime());//;
              
          }
          
          
          
          return liste;
          
          
      }
          
     public ArrayList<String> case_show_detail(int id) throws SQLException{
         
         ArrayList<String> liste=new ArrayList();
          Statement s=(Statement) con.createStatement();
         
         ResultSet r=s.executeQuery("select * from case_first where case_id = " + id);
         System.out.println("1");
         String type="";
          while(r.next()){
              liste.add(r.getString("case_type")+","+r.getString("assigned_to")+","+r.getTimestamp("last_action_date").toString()+","
                      
                      +r.getString("case_status")+","+r.getString("matter_code")+","+r.getTimestamp("starting_date").toString()+","+
                      r.getDate("deadline").toString() +
                      ","+r.getString("payment")+","
              + r.getString("practice") +"," + r.getString("scope") + "," + r.getString("remarks"));
              type=r.getString("case_type");
          }
          if(type.equals("Immigration")){
              r=s.executeQuery("select * from case_im where case_id ="+id);
              
              while (r.next()){
                  liste.add(r.getString("curr_visa")+","+r.getString("exp_date")+","+r.getString("next_visa"));
              }
              
          }
          else  if(type.equals("Business")){
              r=s.executeQuery("select * from case_bus where case_id ="+id);
              
              while (r.next()){
                  liste.add(r.getString("tsaction")+","+r.getString("defendant")+","+r.getString("lawyer_name"));
              }
              
          }
          else if(type.equals("Intellectual Property")){
              r=s.executeQuery("select * from case_ip where case_id ="+id);
              
              while (r.next()){
                  liste.add(r.getString("tsaction"));
              }
              
          }
         else if(type.equals("Malpractice")){
              r=s.executeQuery("select * from case_mal where case_id ="+id);
              
              while (r.next()){
                  liste.add(r.getString("job") + "," + r.getString("suitor_name"));
              }
              
          }
          
          else if(type.equals("Family")){
              r=s.executeQuery("select * from case_fam where case_id ="+id);
              
              while (r.next()){
                  liste.add(r.getString("spouse_name") + "," + r.getString("consensual"));
              }
              
          }      
              
              return liste;
              
          }
     
     public void update_case(ArrayList<String > a) throws SQLException{
         Statement s=(Statement) con.createStatement();
         
         for ( int i=2;i<a.size();i=i+2){
             String quer="update case_first set "+a.get(i)+"='"+a.get(i+1)+"' where case_id="+a.get(1);
             
             if(a.get(i).equals("deadline")){
                   //quer="update case_first set "+a.get(i)+"="+Timestamp.valueOf(new Date(Long.parseLong(a.get(i+1))).toString())+" where case_id="+a.get(1);

                 
             }else{
             
             s.executeUpdate(quer);}
             
         }
         String query="update case_first set last_action_date = (select CURRENT_TIMESTAMP) where case_id="+a.get(1);
         s.executeUpdate(query);
         
         
     }
     
     
     public ArrayList<String> show_employee(int id) throws SQLException{
         ArrayList<String> list = new ArrayList<>();
         Statement s=(Statement) con.createStatement();
          ResultSet r=s.executeQuery("select * from employee_not inner join employee_change on employee_not.emp_id=employee_change.emp_id where employee_not.emp_id="+id);
          
          while(r.next()){
              
              list.add(r.getDate("birth_date") +"," + r.getString("sex")+ "," + r.getString("address") + "," + r.getString("marital")+","+ r.getString("field")+","+ r.getDate("start_date") + "," + r.getInt("salary")+","+ r.getString("email"));
              
                 
          }
          
          return list;
     }
     
     public void add_employee(String fname, String lname, String sex, String birth_date, String marital, String address, String email, String office, String field, int salary) throws SQLException{
           String sorgu = "INSERT INTO employee(fname,lname, office ) VALUES" + "(?,?,?)"; 
           System.out.println("1");
          PreparedStatement preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setString(1, fname);
          preparedStatement.setString(2, lname);
          preparedStatement.setString(3, email);
          
           preparedStatement .executeUpdate();
           
           int id=0;
           Statement s=(Statement) con.createStatement();
           ResultSet r=s.executeQuery("select max(emp_id) emp_id from employee");
           while(r.next()){
               id=r.getInt("emp_id");
           }
           
           sorgu = "insert into employee_change( marital, email, address, salary,emp_id) values " + "(?,?,?,?,?)";
           System.out.println("2");
                
           preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setString(1, marital);
          preparedStatement.setString(2, email);
          preparedStatement.setString(3, address);
          preparedStatement.setInt(4, salary);
          preparedStatement.setInt(5, id);
          
           preparedStatement .executeUpdate();
           
           
           sorgu = "insert into employee_not(sex, birth_date, field,emp_id) values " + "(?,?,?,?)";
           System.out.println("3");
            preparedStatement = con.prepareStatement(sorgu);
          preparedStatement.setString(1, sex);
          preparedStatement.setTimestamp(2, new Timestamp(Long.parseLong(birth_date)));
   
          preparedStatement.setString(3, field);
          preparedStatement.setInt(4, id);
          
           preparedStatement .executeUpdate();
     }
     void delete(int id) throws SQLException{
         Statement s=(Statement) con.createStatement();
         s.executeUpdate("delete from employee_not where emp_id ="+id);
         s.executeUpdate("delete from employee_change where emp_id ="+id);
         s.executeUpdate("delete from employee where emp_id ="+id);
         
         
     }
     
     
     public void updating_employee(String a, String b, String c, String d,int id) throws SQLException{
           PreparedStatement ps = con.prepareStatement(
      "UPDATE employee_change SET marital = ?, email = ? , address = ? , salary = ? WHERE emp_id = ?");

    // set the preparedstatement parameters
    ps.setString(1,a);
    ps.setString(2,b);
    ps.setString(3,c);
    ps.setInt(4,Integer.valueOf(d));
    ps.setInt(5,id);

    // call executeUpdate to execute our sql update statement
    ps.executeUpdate();
             
             
            }
             
         
         
         public ArrayList<String> getEmployee() throws SQLException{
             ArrayList<String> liste=new ArrayList<>();
             
             Statement s=(Statement) con.createStatement();
         ResultSet r=s.executeQuery("select fname from employee");
         int id=0;
		while (r.next()) {
                    liste.add(r.getString("fname"));
                }
             
             
             
             return liste;
             
             
         }
         
     
     }
          
